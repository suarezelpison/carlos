<!DOCTYPE html>
<html>
<head>
    <title>Jewelry Bohemy</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=devide-width, initial-scale=1">
    <link rel="shortcut icon" href="principal/logo.png">
</head>
<body bgcolor="#AED6F1">
   
   <div class="head">
    <hr>
    <center><img src="principal/log.jpg" width="300" height="300"><br>
    <a href="logout.php">Cerrar sesion</a></center>
    <hr>
  </div>


   
     <center>
     	
        <h1>BIENVENIDO ADMINISTRADOR!!!</h1>

	 	<h1>Menus Principal</h1>
 </center>
     <ul>
     	
        <li><a href="principal_admi.php">Ver Pagina Principal</li>
     	<li><a href="agregar_prod_admin.php">Agregar un Nuevo Producto</a></li>
        <li><a href="lista_prod_admi.php">Lista de Prodcutos</li>  
        <li><a href="lista_usuario.php">Lista de usuarios</li>
        <li><a href="nuevo_usuario.php">Agregar un Nuevo usuario</li> 
        <li><a href="logout.php">Salir</a></li>


     </ul>
   
 </body>