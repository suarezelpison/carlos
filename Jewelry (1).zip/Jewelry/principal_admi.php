<!DOCTYPE html>
<html>
<head>
  <title>Jewelry Bohemy</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=devide-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="">
  <link rel="shortcut icon" href="principal/logo.png">
</head>
<body bgcolor="#AED6F1">
   
   <div class="head">
    <hr>
    <center>
      <table border="0">
        <tr>
          <td colspan="4"><img src="anillos/anillo.jpg" width="400" height="400"></td>
        </tr>
        <tr>
          <td width="50"></td>
    <td><a href="administrador.php">Inicio</a></td>
    <td width="150"> </td>
    <td><a href="logout.php">Cerrar sesion</a></center></td>
    
    </tr>
    </table>
    <hr>

  <div class="categoria">
    <center>
      <table border>

       <tr><td colspan="6"><center><h1>CATEGORIAS</h1></center></td>
        
       <tr>
        
      <td><h4>ANILLOS</h4></td>
      <td><a href="anillos.php"><img src="iconos/anillos.png"></a></td>
         
        <td  width="300"></td>
        
      <td><h4>ARITOS</h4></td>
      <td><a href="aritos.php"><img src="iconos/aritos.png"></a></td>
        </tr> 
         <td colspan="6" height="100"></td>
        <tr>
       
      <td><h4>COLLARES</h4></td>
      <td><a href="collares.php"><img src="iconos/collares.png"></a></td>
        
         <td></td>
         
      <td><h4>PULSERAS</h4></td>
      <td><a href="pulseras.php"><img src="iconos/pulseras.png"></a></td>
        </tr> 

    </table>
    </center>
  </div>

</body>
</html>