<!DOCTYPE html>
<html>
<head>
	<title>Jewelry Bohemy</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=devide-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="">
  <link rel="shortcut icon" href="principal/logo.png">
</head>
<body bgcolor="#AED6F1">
    <center>
    <div class="head">
    	<img src="principal/log.jpg" width="300" height="300">

    	<div class="Menulat">
    	   <ul>
    	   	 <li><a href="inicio.php">Iniciar Sesion</a></li>
    	   	 <li><a href="registrarse.php">Registrarse</a></li>
    	   </ul>
    	</div>
    </div>


  <div class="inicio">
     <img src="principal/principal4.jpg">
     <img src="principal/principal2.jpg">	
  </div>

 

    </center>

</body>
</html>