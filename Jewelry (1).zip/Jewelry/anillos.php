<!DOCTYPE html>
<html>
<head>
	<title>Jewelry Bohemy</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=devide-width, initial-scale=1">
    <link rel="shortcut icon" href="principal/logo.png">
</head>
<body bgcolor="#AED6F1">
   
   <div class="head">
    <hr>
    <center>
      <table border="0">
        <tr>
          <td colspan="3"><img src="anillos/anillo.jpg" width="400" height="400"></td>
        </tr>
        <tr>
    <td><a href="principal_usuario.php">Inicio</a></td>
    <td><a href="logout.php">Cerrar sesion</a></center></td>
    <td><a href="aritos.php">siguiente</a></td>
    </tr>
    </table>
    <hr>
  </div>
  <body>
    
    <h1>CATALOGO DE ANILLOS EN NUESTRA TIENDA</h1>
     <center>

      <table border="2">
     <tr>
       <td><img src="anillos/anillo1.jpg" width="255" height="255"></td>
       <td>
        <ul>
          <li>Juego de Anillos Eclipse</li>
          <li>Hermoso juego de 8 anillos dorados que son el complemento ideal para tu look!</li>
          <li>Talla: 5, 6, 7, 8</li>
          <li>Precio: $27.50</li>
       </td>
       <td>
        <button onclick="confirmarAccion()">Realizar compra!</button>

        <script type="text/javascript">
          function confirmarAccion() {
   
          if (confirm("¿Deseas realizar la compra?")){
           //Codigo para eliminir el elemento
          alert("Compra realizada con exito");
          }
           else
          {
         //Codigo para cancelar accion
          alert("Compra cancelada");
         }
         }
        </script>
       </td>
     </ul>
      </tr>
     <ul>



       <tr>
       <td><img src="anillos/anillo2.jpg" width="255" height="255"></td>
       <td>
        <ul>
          <li>Juego de Anillos Amistad Infinita</li>
          <li>Hermoso juego de 14 anillos dorados que simbolizan amor, paz, amistad puedes usarlos como sea tu preferencia!</li>
          <li>Talla: 5, 6, 7, 8</li>
          <li>Precio: $47.50</li>
       </td>
        <td>
        <button onclick="confirmarAccion()">Realizar compra!</button>

        <script type="text/javascript">
          function confirmarAccion() {
   
          if (confirm("¿Deseas realizar la compra?")){
           //Codigo para eliminir el elemento
          alert("Compra realizada con exito");
          }
           else
          {
         //Codigo para cancelar accion
          alert("Compra cancelada");
         }
         }
        </script>
       </td>

     </ul>
      </tr>
     <ul>

        <tr>
       <td><img src="anillos/anillo3.jpg" width="255" height="255"></td>
       <td>
        <ul>
          <li>Juego de Anillos Vibracion</li>
          <li>Hermoso juego de 16 anillos,perfecto para cuakquier ocasion, te haran ver hermosa, estilizada y con un outfit maravilloso y elegante</li>
          <li>Talla: 5, 6, 7, 8</li>
          <li>Precio: $57.50</li>
       </td>
        <td>
        <button onclick="confirmarAccion()">Realizar compra!</button>

        <script type="text/javascript">
          function confirmarAccion() {
   
          if (confirm("¿Deseas realizar la compra?")){
           //Codigo para eliminir el elemento
          alert("Compra realizada con exito");
          }
           else
          {
         //Codigo para cancelar accion
          alert("Compra cancelada");
         }
         }
        </script>
       </td>
     </ul>
      </tr>
     <ul>

        <tr>
       <td><img src="anillos/anillo12.jpg" width="255" height="255"></td>
       <td>
        <ul>
          <li>Juego de Anillos Infinito</li>
          <li>Hermoso juego de 7 anillos, si te gustan los look minimalistas y sencillos pero hermosos, este juego esperfecto para ti!</li>
          <li>Talla: 5, 6, 7, 8</li>
          <li>Precio: $27.50</li>
       </td>
        <td>
        <button onclick="confirmarAccion()">Realizar compra!</button>

        <script type="text/javascript">
          function confirmarAccion() {
   
          if (confirm("¿Deseas realizar la compra?")){
           //Codigo para eliminir el elemento
          alert("Compra realizada con exito");
          }
           else
          {
         //Codigo para cancelar accion
          alert("Compra cancelada");
         }
         }
        </script>
       </td>
     </ul>
      </tr>
     <ul>

        <tr>
       <td><img src="anillos/anillo5.jpg" width="255" height="255"></td>
       <td>
        <ul>
          <li>Juego de Anillos Pasión</li>
          <li>Hermoso juego de 6 anillos con incruste de diamante, perfectos para completar tu look sofisticado y elegante!</li>
          <li>Talla: 5, 6, 7, 8</li>
          <li>Precio: $27.50</li>
       </td>
        <td>
        <button onclick="confirmarAccion()">Realizar compra!</button>

        <script type="text/javascript">
          function confirmarAccion() {
   
          if (confirm("¿Deseas realizar la compra?")){
           //Codigo para eliminir el elemento
          alert("Compra realizada con exito");
          }
           else
          {
         //Codigo para cancelar accion
          alert("Compra cancelada");
         }
         }
        </script>
       </td>
     </ul>
      </tr>
     <ul>
</table>
</center>

  </body>

  </html>